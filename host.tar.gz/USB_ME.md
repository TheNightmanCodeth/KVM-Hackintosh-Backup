Keyboard (Drop ALT): 
    |_ ID = (04d8:eed3/eec5)
    |_ USBC bus/addr = 001/(006&005)
Mouse (Corsair):
    |_ ID = 1b1c:1b12
    |_ Rear (Top-right) bus/addr = 003/005
Audio Adapter:
    |_ ID = 0d8c:0014
    |_ Rear (Second-from-top, left) = 003/005

Bus 004 Device 001: ID 1d6b:0003 Linux Foundation 3.0 root hub
Bus 003 Device 005: ID 0d8c:0014 C-Media Electronics, Inc. Audio Adapter (Unitek Y-247A)
Bus 003 Device 006: ID 1b1c:1b12 Corsair 
Bus 003 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub
Bus 002 Device 001: ID 1d6b:0003 Linux Foundation 3.0 root hub
Bus 001 Device 006: ID 04d8:eed3 Microchip Technology, Inc. 
Bus 001 Device 005: ID 04d8:eec5 Microchip Technology, Inc. 
Bus 001 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub

# Diagram

### Legend

{} = USB-2.0 Port
[] = USB-3.0 Port
() = USB-C Port

## Rear

  01 02
A {} {}

B () []
C [] []
D [] []

## Front Panel

  01 02
F [] [] (Power)






