# EFIFB

This son of a bitch won't let me use my GPU with vfio. It needs to be disabled somehow.

## Options

- Add (video=efifb:off) to linux args
- Blacklist efifb
- This: 
```
echo 0 > /sys/class/vtconsole/vtcon0/bind
echo 0 > /sys/class/vtconsole/vtcon1/bind
echo efi-framebuffer.0 > /sys/bus/platform/drivers/efi-framebuffer/unbind
```
