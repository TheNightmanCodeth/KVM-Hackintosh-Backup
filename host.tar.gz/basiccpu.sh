#!/bin/bash

##########################################
### It's the realest and illest killas ###

echo 0 > /sys/class/vtconsole/vtcon0/bind
echo 0 > /sys/class/vtconsole/vtcon1/bind
echo efi-framebuffer.0 > /sys/bus/platform/drivers/efi-framebuffer/unbind

OSK="ourhardworkbythesewordsguardedpleasedontsteal(c)AppleComputerInc"
VMDIR=$PWD
OVMF=$VMDIR/firmware

NOW=$(date +"%D %T")
echo "========== NEW START ==========" >> qemu.out
echo "====== $NOW ======" >> qemu.out

qemu-system-x86_64 \
    -enable-kvm \
    -m 30G \
    -nographic \
    -machine q35,accel=kvm \
    -smp $(nproc) \
    -cpu Penryn,vendor=GenuineIntel,kvm=on,+invtsc,vmware-cpuid-freq=on,+aes,+avx,+avx2,+bmi1,+bmi2,check,+fma,+movbe,+pcid,+popcnt,+smep,+sse3,+sse4.2,+xgetbv1,+xsave,+xsavec,+xsaveopt \
    -device isa-applesmc,osk="$OSK" \
    -smbios type=2 \
    -drive if=pflash,format=raw,readonly,file=$OVMF/OVMF_CODE.fd \
    -drive if=pflash,format=raw,file=$OVMF/macOS_VARS.fd \
    -vga qxl \
    -device ich9-intel-hda -device hda-duplex \
    `: # Massdrop ALT keyb` \
    -usb -device usb-host,vendorid=0x04d8,productid=0xeed3,hostbus=1 \
    -device usb-kbd \
    -device usb-host,vendorid=0x04d8,productid=0xeec5,hostbus=1 \
    `: # Corsair mouse` \
    -device usb-host,vendorid=0x1b1c,productid=0x1b12,hostbus=3 \
    -device usb-mouse \
    `: # USB Audio card` \
    -device usb-host,vendorid=0x0d8c,productid=0x0014,hostbus=3 \
    -device usb-audio \
    `: # Pixel 2 XL` \
    `: # USB SD Card reader` \
    -device usb-host,vendorid=0x05e3,productid=0x0716,hostbus=1 \
    -monitor unix:qemu.socket,server,nowait `: # The qemu console socket` \
    -netdev user,id=net0 \
    -device e1000-82545em,netdev=net0,id=net0,mac=52:54:00:c9:18:27 \
    -device ich9-ahci,id=sata \
    `: # The boot drive must be sata.2 (unless you want to fuck with the bios lol)` \
    -drive id=ESP,if=none,format=qcow2,file=ESP.qcow2 \
    -device ide-hd,bus=sata.2,drive=ESP \
    `: # The system drive` \
    -drive id=Mojave,if=none,format=raw,file=/dev/sda \
    -device ide-hd,bus=sata.4,drive=Mojave \
    `: # PCIE passthrough` \
    -vga none \
    -device pcie-root-port,bus=pcie.0,multifunction=on,port=1,chassis=1,id=port.1 \
    -device vfio-pci,host=26:00.0,bus=port.1,multifunction=on \
    -device vfio-pci,host=26:00.1,bus=port.1 &>> qemu.out

echo "==========    END    ==========" >> qemu.out
echo "===============================" >> qemu.out
